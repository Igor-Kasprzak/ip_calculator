var MASKS = [
    '255.0.0.0',
    '255.128.0.0',
    '255.192.0.0',
    '255.224.0.0',
    '255.240.0.0',
    '255.248.0.0',
    '255.252.0.0',
    '255.254.0.0',
    '255.255.0.0',
    '255.255.128.0',
    '255.255.192.0',
    '255.255.224.0',
    '255.255.240.0',
    '255.255.248.0',
    '255.255.252.0',
    '255.255.254.0',
    '255.255.255.0',
    '255.255.255.128',
    '255.255.255.192',
    '255.255.255.224',
    '255.255.255.240',
    '255.255.255.248',
    '255.255.255.252',
    '255.255.255.254',
    '255.255.255.255'
];
var init = function () {
    clearOutPut();
    updateClass();
};
var clearOutPut = function () {
    document.getElementById('outputBase').innerHTML = '&#160;';
    document.getElementById('outputFirst').innerHTML = '&#160;';
    document.getElementById('outputLast').innerHTML = '&#160;';
    document.getElementById('outputBroadcast').innerHTML = '&#160;';
};
var showOutput = function () {
    clearOutPut();
    var addressIp = document.querySelector('input[name="addressIp"]').value;
    if (addressIp.match(/^((25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}(25[0-5]|2[0-4]\d|[01]?\d?\d)$/) == null) {
        alert("Wprowadzono błędny adres IP.");
        return;
    }
    var maskIp = document.querySelector('select[name="maskIp"]').value;
    var base = getBaseAddress(addressIp, maskIp);
    var broadcast = getBroadcastAddress(addressIp, maskIp);
    document.getElementById('outputBase').innerHTML = base;
    document.getElementById('outputFirst').innerHTML = getFirstHost(base);
    document.getElementById('outputLast').innerHTML = getLastHost(broadcast);
    document.getElementById('outputBroadcast').innerHTML = broadcast;
};
var getBaseAddress = function (addressIp, maskIp) {
    var adressArray = addressIp.split('.');
    var classArray = maskIp.split('.');
    var resultArray = [];
    adressArray.forEach(function (adressSegment, idxAdressSegment) {
        resultArray[idxAdressSegment] = parseInt(adressSegment, 10) & parseInt(classArray[idxAdressSegment], 10);
    });
    return resultArray.join('.');
};
var getBroadcastAddress = function (addressIp, maskIp) {
    var adressArray = addressIp.split('.');
    var classArray = maskIp.split('.');
    var resultArray = [];
    classArray.forEach(function (classSegment, idxClassSegment) {
        resultArray[idxClassSegment] = parseInt(adressArray[idxClassSegment], 10) & parseInt(classSegment, 10);
        resultArray[idxClassSegment] += Math.abs(parseInt(classSegment, 10) - 255);
    });
    return resultArray.join('.');
};
var getFirstHost = function (baseAddress) {
    var resultArray = baseAddress.split('.');
    resultArray[3] = (parseInt(resultArray[3], 10) + 1).toString(10);
    return resultArray.join('.');
};
var getLastHost = function (broadcastAddress) {
    var resultArray = broadcastAddress.split('.');
    resultArray[3] = (parseInt(resultArray[3], 10) - 1).toString(10);
    return resultArray.join('.');
};
var updateClass = function () {
    clearOutPut();
    var maskIp = parseInt(document.querySelector('input[name="classIp"]:checked').value, 10);
    var select = document.querySelector('select[name="maskIp"]');
    select.options.length = 0;
    var option;
    for (var i = maskIp; i < MASKS.length; i++) {
        option = document.createElement('option');
        option.value = MASKS[i];
        option.text = MASKS[i];
        select.options.add(option);
    }
};
